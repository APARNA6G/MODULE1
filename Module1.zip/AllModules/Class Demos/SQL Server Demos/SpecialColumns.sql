USE Training_23Jan19_Pune

--Computed Columns
CREATE TABLE Marks_115022
(
	Test1		INT,
	Test2		INT,
	Total		AS (Test1 + Test2),
	TestAvg		AS ((Test1 + Test2)/2)
)


--The column "Total" and "TestAvg" cannot be modified because it is either a computed column or is the result of a UNION operator.
--INSERT INTO Marks_115022 (Test1, Test2, Total, TestAvg)
--VALUES(20, 30, 50, 25)

INSERT INTO Marks_115022
VALUES (20, 30)

INSERT INTO Marks_115022 (Test1, Test2)
VALUES(40, 34)

SELECT * FROM Marks_115022

EXEC sp_help Marks_115022

--Identity Column
CREATE TABLE Printer_115022
(
	PrinterID		INT	IDENTITY(1000, 3),
	PrinterName		VARCHAR(40)
)

--Error : Cannot insert explicit value for identity column in table 'Printer_115022' when IDENTITY_INSERT is set to OFF.
--INSERT INTO Printer_115022(PrinterID, PrinterName)
--VALUES (101, 'HP Laser')

INSERT INTO Printer_115022(PrinterName)
VALUES('HP Laser')

INSERT INTO Printer_115022(PrinterName)
VALUES('Dot Matrix')

INSERT INTO Printer_115022(PrinterName)
VALUES('Canon')

SELECT * FROM Printer_115022

EXEC sp_help Printer_115022

--UniqueIdentifier Column
CREATE TABLE Hardware_115022
(
	HardwareID		UNIQUEIDENTIFIER,
	HardwareName	VARCHAR(20)
)

--Error : Operand type clash: int is incompatible with uniqueidentifier
--INSERT INTO Hardware_115022(HardwareID, HardwareName)
--VALUES (101, 'Printer')

INSERT INTO Hardware_115022(HardwareID, HardwareName)
VALUES(NEWID(), 'Printer')

INSERT INTO Hardware_115022(HardwareID, HardwareName)
VALUES(NEWID(), 'Keyboard')

INSERT INTO Hardware_115022(HardwareID, HardwareName)
VALUES(NEWID(), 'Mouse')

SELECT * FROM Hardware_115022

EXEC sp_help Hardware_115022