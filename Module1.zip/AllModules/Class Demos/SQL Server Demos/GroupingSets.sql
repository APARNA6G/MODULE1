USE Training_23Jan19_Pune

--Column Name is Problem
SELECT Dept_Code, COUNT(Staff_Code) Staff_Count
FROM Staff_Master
GROUP BY Dept_Code
UNION
SELECT Des_Code, COUNT(Staff_Code) Staff_Count
FROM Staff_Master
GROUP BY Des_Code

--To resolve above problem solution is use extra column
SELECT Dept_Code, Des_Code=NULL, COUNT(Staff_Code) Staff_Count
FROM Staff_Master
GROUP BY Dept_Code
UNION
SELECT Dept_Code=NULL, Des_Code, COUNT(Staff_Code) Staff_Count
FROM Staff_Master
GROUP BY Des_Code


--Problem is datatype of the column
SELECT Dept_Code, COUNT(Stud_Code) Stud_Count
FROM Student_master
GROUP BY Dept_Code
UNION
SELECT Address, COUNT(Stud_Code) Stud_Count
FROM Student_master
GROUP BY Address

SELECT Dept_Code, Address=NULL, COUNT(Stud_Code) Stud_Count
FROM Student_master
GROUP BY Dept_Code
UNION
SELECT Dept_Code=NULL, Address, COUNT(Stud_Code) Stud_Count
FROM Student_master
GROUP BY Address

--GROUPING SETS
SELECT Dept_Code, Des_Code, COUNT(Staff_Code) Staff_Count
FROM Staff_Master
GROUP BY GROUPING SETS ((Dept_Code), (Des_Code))

SELECT Dept_Code, Address, COUNT(Stud_Code) Stud_Count
FROM Student_master
GROUP BY GROUPING SETS ((Dept_Code), (Address))