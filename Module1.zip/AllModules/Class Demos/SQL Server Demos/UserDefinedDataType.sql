USE Training_23Jan19_Pune

CREATE TYPE EmailAddress_115022
FROM VARCHAR(50) NOT NULL

CREATE TABLE Emp_115022
(
	EmpID		INT,
	EmpName		VARCHAR(20),
	DOJ			DATE,
	Email		EmailAddress_115022,
	Phone		CHAR(10)
)

EXEC sp_help Emp_115022

SELECT * FROM Emp_115022

DROP TYPE EmailAddress_115022