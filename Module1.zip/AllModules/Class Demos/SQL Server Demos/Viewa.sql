USE Training_23Jan19_Pune

--Create view for storing data stud_code, stud_name, and dept_code
CREATE VIEW StudentView_115022
AS
SELECT Stud_Code, Stud_Name, Dept_Code
FROM Student_master

SELECT * FROM StudentView_115022

SELECT * FROM syscomments WHERE text LIKE '%115022%'

--Create view to store staff_code, staff_name, designation_name,
--department_name for all staff
CREATE VIEW StaffView_115022
AS
SELECT sm.Staff_Code, sm.Staff_Name, des.Design_Name, dept.Dept_Name
FROM Staff_Master sm INNER JOIN Desig_master des
ON sm.Des_Code = des.Design_Code
INNER JOIN Department_master dept
ON sm.Dept_Code = dept.Dept_code

--Create view to show deptartment wise student count
--Hide the definition of View
CREATE VIEW StudCountView_115022
WITH ENCRYPTION
AS
SELECT Dept_Code, COUNT(Stud_Code) AS Stud_Count
FROM Student_master
GROUP BY Dept_Code

SELECT * FROM StudCountView_115022