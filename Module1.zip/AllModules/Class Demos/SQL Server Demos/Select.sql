USE Training_23Jan19_Pune

--All columns and all rows
SELECT * FROM Employee_115022

--Sepcific columns and all rows
SELECT Employee_Code, Employee_Name
FROM Employee_115022

--Specific columns and specific rows
--Display all products from category 1
SELECT ProdID, ProdName, CategoryID
FROM Product_115022
WHERE CategoryID = 1

--Sort the data
SELECT *
FROM Employee_115022
ORDER BY Employee_Code

--Sort the data in descending manner
SELECT *
FROM Employee_115022
ORDER BY Employee_Code DESC

--Multiple columns in Order By
SELECT Staff_Code, Staff_Name, Des_Code, Dept_Code
FROM Staff_Master
ORDER BY Des_Code, Dept_Code

SELECT Staff_Code, Staff_Name, Des_Code, Dept_Code
FROM Staff_Master
ORDER BY Des_Code, Dept_Code DESC

SELECT Staff_Code, Staff_Name, Des_Code, Dept_Code
FROM Staff_Master
ORDER BY Des_Code DESC, Dept_Code DESC