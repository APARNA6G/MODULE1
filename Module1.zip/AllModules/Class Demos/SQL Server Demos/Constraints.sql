USE Training_23Jan19_Pune

EXEC sp_help Emp_115022

--DEFAULT
INSERT INTO Emp_115022(EmpID, EmpName, Email, DOB)
VALUES(1002, 'Maria', 'maria@cg.com', '2004-04-04')

SELECT * FROM Emp_115022

ALTER TABLE Emp_115022
ADD CONSTRAINT DF_Phone_115022 DEFAULT '0000000000' FOR Phone

INSERT INTO Emp_115022(EmpID, EmpName, Email, DOB)
VALUES(1003, 'Allister', 'allister@cg.com', '1994-06-12')

INSERT INTO Emp_115022(EmpID, EmpName, Email, DOB, Phone)
VALUES(1004, 'Danial', 'danial@cg.com', '1993-06-12', '9998887776')

--CHECK
DELETE FROM Emp_115022 WHERE EmpID = 1002

ALTER TABLE Emp_115022
ADD CONSTRAINT CK_DOB_115022 CHECK(DOB >= '1970-01-01' AND DOB < '2001-01-01')

INSERT INTO Emp_115022(EmpID, EmpName, Email, DOB)
VALUES(1002, 'Maria', 'maria@cg.com', '1999-04-04')

--PRIMARY KEY
ALTER TABLE Emp_115022
ALTER COLUMN EmpID INT NOT NULL

ALTER TABLE Emp_115022
ADD CONSTRAINT PK_Emp_115022 PRIMARY KEY NONCLUSTERED (EmpID)

SELECT * FROM Emp_115022

INSERT INTO Emp_115022(EmpID, EmpName, Email, DOB, Phone)
VALUES(1005, 'Sofia', 'Sofia@cg.com', '1989-12-12', '9678587776')

--UNIQUE
ALTER TABLE Emp_115022
ADD CONSTRAINT U_Email UNIQUE NONCLUSTERED (Email)

INSERT INTO Emp_115022(EmpID, EmpName, Email, DOB, Phone)
VALUES(1006, 'Tennyson', 'tennyson@cg.com', '1992-05-16', '9123456789')

--Foreign Key
CREATE TABLE Category_115022
(
	CatID		INT		CONSTRAINT PK_Category_115022 PRIMARY KEY,
	CatName		VARCHAR(20)
)

INSERT INTO Category_115022 (CatID, CatName)
VALUES(1, 'Stationary'),
(2, 'Accessories'),
(3, 'Toys'),
(4, 'Gift Items')

CREATE TABLE Product_115022
(
	ProdID		INT				PRIMARY KEY,
	ProdName	VARCHAR(30),
	Quantity	INT				CONSTRAINT CK_Qty_115022 CHECK(Quantity > 3),
	Price		MONEY,
	CategoryID	INT				CONSTRAINT FK_Prod_Cat_115022 REFERENCES Category_115022(CatID)
)

INSERT INTO Product_115022(ProdID, ProdName, Quantity, Price, CategoryID)
VALUES(101, 'Pencil', 7, 3, NULL)

INSERT INTO Product_115022(ProdID, ProdName, Quantity, Price, CategoryID)
VALUES(102, 'NoteBook', 10, 30, 1)

INSERT INTO Product_115022(ProdID, ProdName, Quantity, Price, CategoryID)
VALUES(103, 'Doll', 5, 250, 3)

--Disabled the constraint
ALTER TABLE Product_115022
NOCHECK CONSTRAINT CK_Qty_115022

INSERT INTO Product_115022(ProdID, ProdName, Quantity, Price, CategoryID)
VALUES(104, 'Toy Car', 2, 250, 3)

--Enabled the constraint
ALTER TABLE Product_115022
CHECK CONSTRAINT CK_Qty_115022

INSERT INTO Product_115022(ProdID, ProdName, Quantity, Price, CategoryID)
VALUES(105, 'Scale', 4, 5, 1)