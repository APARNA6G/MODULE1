USE Training_23Jan19_Pune

--Write a procedure to access the students based on city
CREATE PROC usp_RetrieveStudByCity_115022
(
	@city		VARCHAR(30)
)
AS
BEGIN
	IF (@city IS NULL OR @city = '') 
	BEGIN
		PRINT 'City should be provided'
	END
	ELSE
	BEGIN
		SELECT Stud_Code, Stud_Name, Address
		FROM Student_master
		WHERE Address = @city
	END
END

SELECT * FROM syscomments WHERE text LIKE '%115022%'

EXEC usp_RetrieveStudByCity_115022 'chennai'

EXEC usp_RetrieveStudByCity_115022 @city = 'chennai'

EXEC usp_RetrieveStudByCity_115022 'bangalore'

EXEC usp_RetrieveStudByCity_115022 null

EXEC usp_RetrieveStudByCity_115022 ''

--Write a store procedure to display the count of students 
--from particular department
ALTER PROC usp_StudCountDept_115022
(
	@DCode		INT,
	@SCount		INT		OUT
)
AS
BEGIN
	IF(@DCode IS NULL OR @DCode <= 0)
	BEGIN
		PRINT 'Department Code should be provided and it cannot be 0 or negative'
	END
	ELSE
	BEGIN
		IF EXISTS (SELECT Dept_Code 
				FROM Department_master 
				WHERE Dept_code = @DCode)
		BEGIN
			SELECT @SCount = COUNT(Stud_Code)
			FROM Student_master
			WHERE Dept_Code = @DCode
		END
		ELSE
		BEGIN
			PRINT 'Department Code ' + str(@DCode) + ' does not exists'
		END
	END
END

DECLARE @count INT
EXEC usp_StudCountDept_115022 20, @count OUT
SELECT @count


--Executing stored procedure with result sets
EXEC usp_RetrieveStudByCity_115022 'chennai' 
WITH RESULT SETS((SCode INT, SName VARCHAR(20), City VARCHAR(20)))

--To View the definition of stored procedure
SELECT * FROM syscomments WHERE text LIKE '%115022%'

SELECT OBJECT_DEFINITION(OBJECT_ID('usp_RetrieveStudByCity_115022'))

EXEC sp_helptext usp_RetrieveStudByCity_115022