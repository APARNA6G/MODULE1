USE Training_23Jan19_Pune

SELECT * From Student_Marks

SELECT	Stud_Code, 
		Subject1, Subject2, Subject3, 
		(Subject1+Subject2+Subject3) Total
FROM Student_Marks

SELECT	Stud_Code, 
		Subject1, Subject2, Subject3, 
		(Subject1+Subject2+Subject3) Total,
		(Subject1+Subject2+Subject3)/3 Average
FROM Student_Marks

SELECT	Stud_Code, 
		Subject1, Subject2, Subject3, 
		(Subject1+Subject2+Subject3) Total,
		(Subject1+Subject2+Subject3)/3 Average
FROM Student_Marks

SELECT	Stud_Code, 
		Subject1, Subject2, Subject3, 
		(Subject1+Subject2+Subject3) Total,
		(Subject1+Subject2+Subject3)/3 Average,
		(Subject1+Subject2+Subject3)/300 * 100 Percentage
FROM Student_Marks